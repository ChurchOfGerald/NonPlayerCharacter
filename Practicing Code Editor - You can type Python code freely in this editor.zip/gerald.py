print('Hello World! 1')
# If you read this you will have a curse upon you that will bring you misfortune for the rest of your life

qwertyuiop = 15 // 2
print(qwertyuiop)

sum = 15 + 15
difference = 15 - 15
product = 15 * 15
quotient = 15 // 15

print(sum)
print(difference)
print(product)
print(quotient)