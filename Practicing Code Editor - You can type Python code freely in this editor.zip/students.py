Name = "Gerald"
Age = "Above the concept of time, immortal"
GPA = "pick random between 2 and 6 octillion"
ClassRank = "#1 the goat"
SchoolName = "Gerald's school for the awesome"


print("Name: " +Name)
print("Age: " +Age)
print("GPA: " +GPA)
print("Class Rank: " +ClassRank)
print("School name: " +SchoolName)