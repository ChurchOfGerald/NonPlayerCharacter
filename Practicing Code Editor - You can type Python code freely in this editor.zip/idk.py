scores = [95, 12, 23, 67, 21, 89, 67, 40, 57, 100, 150, -5]

for i in scores:
   if  100 >= i >= 90:
       print("Score:",i," - Grade:A")
   elif  90     > i >= 80:
         print("Score:",i," - Grade:B")
   elif 80 > i >= 70:
       print("Score:",i," - Grade:C")
   elif 70 > i >= 60:
       print("Score:",i," - Grade:D")
   elif 0 <= i < 60:
       print("Score:",i," - Grade:F")
   elif i > 100:
       print("Error: Score above 100.")
   elif i < 0:
       print("Error: Score below 0.")