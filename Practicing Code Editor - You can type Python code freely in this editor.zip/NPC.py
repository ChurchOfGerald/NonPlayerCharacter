import random
import math
#importing both now just for later

names = []
while len(names) < 10:
    names.append(input("Enter an NPC Name:")) #adds until 10 names inputted
    
#Names are what is inputted and the age is somewhat based on it
characteristics = ["Funny", "Smart", "Kind", "Rude", "Narcissistic", "Humble", "Confident", "Cheerful", "Vengeful", "Hard-Working", "Courageous", "Ambitious", 
"Calm", "Creative", "Disciplined", "Honest", "Loyal", "Patient", "Intellegent", "Cooperative", "Curious", "Ennergetic"]
attributes = ["Tall", "Short", "Rotund", "Strong", "Weak", "Stylish", "Proper", "Fat", "Skinny", "Bald", "Well-Kept", "Messy"]
status = ["Impoverished", "Slave", "Poor", "Lower Class", "Middle Class", "Rich", "Very High Class", "Royalty"]
#list of random attributes


for name in names: #runs for each NPC name entered. Each one of this code returns one full NPC setup, and just reapeats for the rest afterwards.
    age = len(name)*4
    finalAge = random.uniform(age-10, age+20)
    finalAge = finalAge // 1 + random.choice([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]) #sets age dependant on length of the initial name. The float is converted to being flat in the decimals but then gets added back from random.choice (removes floats that are too long)
    if finalAge <= 0:
        finalAge = random.uniform(age-3, age+20) #If age is 0 or less, it rerolls without the ability to get to or below 0 to avoid this.
        finalAge = (finalAge // 1) + random.choice([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9])
    if finalAge <= 4:
        baby = True #People under 4 years old are babies!!
    else:
        baby = False #Older than 4 is out of baby territory.
    if baby == True:
        print("==================================\n"+"Name:",name,
        "\nAge:",finalAge,
        "\nCharacteristic: BABY",
        "\nAttribute: BABY","\nStatus:",
        random.choice(status)) #babies are too young to have characteristics or attributes
    else:
        print("==================================\n"+"Name:",name,
        "\nAge:",finalAge,
        "\nCharacteristic:",random.choice(characteristics),
        "\nAttribute:",random.choice(attributes),"\nStatus:",
        random.choice(status)) #Prints name, then age, etc in a good format.